#include<stdio.h>
#include<stdlib.h>

int main(){
    char id[11]; //產生一個長度為11的陣列來存放身分證字號（10格＋1格"\0")
    id[0] = rand() % 26 + 65;
    printf("%c", id[0])
}